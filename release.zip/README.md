# hideAncestryBanner
Hide the Ancestry banners announcing maintenance windows and privacy policy changes.
