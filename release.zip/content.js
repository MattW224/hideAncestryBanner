var ancestryBanner = document.getElementById('BannerRegion');
if(ancestryBanner !== null) {
    ancestryBanner.style.display = 'none';
}